#!/usr/bin/env python
# coding: utf-8

# In[4]:


#Taller 1


# ![imagen_2022-02-17_231055.png](attachment:imagen_2022-02-17_231055.png)

# In[ ]:


# Michael Gonchar.(28 de Febrero de 2019).Teach About Climate Change With These 24 New York Times Graphs. New York Times.
# https://www.nytimes.com/2019/02/28/learning/teach-about-climate-change-with-these-24-new-york-times-graphs.html


# In[6]:


## primer Modismo
# ¿qué?
#Tipos de Datos
# Dataset 
# * También muestra items, que son los años.
# * Muestra atributos, que en este caso son los meses donde muestra la ocurrencia de tormentas. 
# * Por lo que es una tabla, que al seleccionar la forma de semicirculo arroja un valor.
# * Los atributos son estaticos ya que arrojan un valor tomado en el tiempo determinado, aunque se pronostica en una fecha
#   determinada que podria a ser temporal. 


# ![imagen_2022-02-17_233152.png](attachment:imagen_2022-02-17_233152.png)

# In[7]:


#Tipos de Atributos
# son categoricos ya que no hay relacion con cada uno de los datos. Porque las tormentas las muestran en diferentes meses 
# del año algunas graves mientras otras no. 
# Aunque pueden ser de orden ordinales si se clasifica cada tormneta de un color y observar el tamaño y el orden en que se
# presentan. 


# In[8]:


## ¿Por qué?
#Abstraccion de las tareas
# * Identificar distribuciones, porque en cada año podemos ver diferentes picos o tambien lo podemos hacer por meses.
# * Identificar datos atipicos, ya sea por un mes en el que la ocurrencia no sea adecuada. 
# * Comparar Tendencias, en diferentes años ver cual fue el commportamiento de tormentas y compararlas con la de los demás.
#Objetivos 
# * Todos los datos: Se presentan diferentes caracteristicas dependiendo del color, ademas podemos ver tendencias por medio
#   de los años o tamaño del costo de la tormenta. 
# * Atributos: se puede identificar los extremos por medio del primer mes y el ultimo mes. Tambien la similitud de ocurrencia
#   de datos y tormentas.


# ![imagen_2022-02-17_234639.png](attachment:imagen_2022-02-17_234639.png)

# In[9]:


# Por ejemplo aqui podemos ver que ocurrieron dos desastres entre mayo y junio.


# In[10]:


## ¿Como?
#Es interactivo, se puede seleccionar cada forma y ver el dato que arroja. 
#Los tonos de color permiten identificar que tipo de tormenta es.
#La tonalidad del color permite observar que hubo otra tormenta durante otra que se haya presentado. 
#El tamaño de la forma saber que tan afectado termino el pais por el costo de daño que provoca cada tormenta. 


# In[11]:


## Marcas
# * Areas: es el tamaño y costo que tuvo cada tormenta.
# * La posicion usa ambos tanto horizontal como vertical, pero se aprecia mas por vertical. 
## Canales
# * Color: usa diferentes tonalidades para identificar el tipo de tormenta. 
# * Forma: Son semicirculos que reflejan el impacto en cuestion de costo. 
# * Agrupacion: permite observar el año y la cantidad de tormentas en un periodo ddeterminado.


# In[1]:


# Cumple 
# * El tamaño permite identificar el impacto de cada tormenta.
# * Los tonos de color permiten identificar el tipo de categoria. 
# * Al colocar la interactividad permite mejorar la informacion. 
# No cumple
# * La longitud de los meses no permite adecuar y agrupar de forma adecuada los datos. Por en Diciembre tiene mayor longitud.
# * Al momento de interactuar se presentan problemas con los desastres de menor impacto no los permite reconocer. 
# * Los colores en la saturacion se pierden algunos. 
# * El nombre de cada desastre era innecesario. 
# Mejoras
# Distribuir mejor los meses, podria haber usado una tabla con los años y meses, e interactuar con cada mes y al momento de
# hacer eso mostrar el impacto como un diagrama de cada desastre presentado, con su respectivo nombre. Ya que se puede 
# confundir con la duracion del desatre si se ve de forma horizontal. 


# ![imagen_2022-02-18_230132.png](attachment:imagen_2022-02-18_230132.png)

# In[ ]:


# Enlace: https://www.datos.gov.co/d/x9vi-iv8c


# In[ ]:


# Saber 11 2019-2. (11 de Febrero de 2020). PUNTAJES ICFES POR DEPARTAMENTO.GOV.CO.https://www.datos.gov.co/d/x9vi-iv8c


# In[2]:


## Segundo Modismo
# ¿Qué?
#Tipos de datos
# Son Items y atributos, ya que a cada item en este caso el departamento se le coloca un atributo que vendria a ser el
# puntaje promedio, y asi con cada uno. 
#Tipos de Dataset y datos
# Seria una tabla, mas especifico un diagrama de barras, a cada item por medio de una barra se le asigna una barra o un 
# punto. 
#Disponibilidad de los datos
# Son estaticos, los items ya son nombrados y los atributos ya son denotados segun estadisticas. 
#Tipos de Atributos
# Son de orden cuantitativo, ya que hay porcentajes mayores o menores segun corresponda a cada item.
# Se muestra con una secuencia descendente.


# In[3]:


# ¿Por qué?
#Analizar
# el principal consumo es presentar, ya que visualiza el atributo a cada item, es decir a cada departamento le designa su 
# promedio y lo muestra en el diagrama. 
# al momento de produicir, recorre del mayor promedio al menor. 
#Buscar
# es una busqueda en la que ya tenemos la ubicacion conocida en este caso podria ser el maximo, con un objetivo que seria 
# el promedio mas alto. 
#Consultar
# Identificar y comparar.
#Todos los datos 
# tendencias y caracteristicas. 
# Es decir que con esta visualizacion podemos identificar tendencias como es el minimo y el maximo, y tambien de comparar
# cada departamentop con su promedio.


# In[4]:


# ¿Como?
#Arreglar
# Es ordenado y separado, es decir el orden en el sentido de descendencia y separada ya que muestra diferentes items. 
# Hay un tono de color, por la relacion de los atributos cuantitativos 


# In[5]:


# Canales
#Posicion 
# Usa ambas tanto vertical como horizontal, vertical los promedios y horizontal los departamentos. 
#Forma
# Usa un diagrama de barras para identificar maximos y minimos o una relacionn de similitud. 
# Marcas
# Puntos, porque aunque muestre barras, esa barra tiene  un limite que es ls posicion vertical que representa el atributo.
# Usa estos canales y marcas porque le permiten al usuario detectar de que hay relacion entre los datos, como son maximos 
# y minimos, similitudes. 


# In[6]:


# Cumple
# El usuario puede identificar informacion rapida. 
# no hay informacion acumulada. 
# El usuario puede recorrer cada dato en orden descendente. 


# In[7]:


# No cumple
# la inclinacion de los datos, hace que el usuario pierda la posicion de una barra. y los numeros que aparecen es 
# irrelevante ya que usan la interactividad para posicionarse en cada barra. 


# In[ ]:


# Mejoras

# Quitar los datos que aparecen en vertical de las barras, es informacion perdida. 
# ya que usan la interactividad quitar el nombre de cada departamento y solo irian en esa posicion el item de departamentos.

